"""Continuous state and generic hybrid integration primitives.

CVT-specific evaluators remain in their own modules rather than being imported
here: dynamics depends on this package's state definitions, so eagerly
importing a CVT adapter would create an import cycle.
"""

from .cvt_operating_limits import CVTShiftOperatingLimits
from .cvt_regime import CVTEngagementState, CVTOperatingRegime, CVTShiftConstraint
from .cvt_regime_events import CVTRegimeEvent
from .hybrid import (
    HybridEvent,
    HybridIntegrationResult,
    HybridIntegratorSettings,
    HybridSegment,
    HybridSystem,
    HybridTransition,
    HybridTransitionRecord,
    integrate_hybrid,
)
from .cvt_shift_limits import EngagedShiftTravelLimits
from .state import CVTDynamicState, CVTDynamicStateDerivative

__all__ = [
    "CVTDynamicState",
    "CVTDynamicStateDerivative",
    "CVTEngagementState",
    "CVTOperatingRegime",
    "CVTRegimeEvent",
    "CVTShiftConstraint",
    "CVTShiftOperatingLimits",
    "EngagedShiftTravelLimits",
    "HybridEvent",
    "HybridIntegrationResult",
    "HybridIntegratorSettings",
    "HybridSegment",
    "HybridSystem",
    "HybridTransition",
    "HybridTransitionRecord",
    "integrate_hybrid",
]
