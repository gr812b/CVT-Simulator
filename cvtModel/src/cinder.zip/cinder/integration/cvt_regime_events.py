"""Geometry and unilateral-constraint events for CVT operating regimes.

These functions intentionally do not contain an RHS.  They encode which
boundaries are meaningful in each regime; the eventual deadzone and
stop-constrained RHS implementations supply any release-tendency callbacks.
"""

from __future__ import annotations

from enum import Enum
from typing import Callable

import numpy as np
from numpy.typing import NDArray

from .cvt_operating_limits import CVTShiftOperatingLimits
from .hybrid import HybridEvent


class CVTRegimeEvent(str, Enum):
    """Events that change engagement or unilateral shift constraint."""

    ENGAGEMENT_REACHED = "engagement_reached"
    DISENGAGEMENT_REACHED = "disengagement_reached"
    LOWER_STOP_REACHED = "lower_stop_reached"
    UPPER_STOP_REACHED = "upper_stop_reached"
    LOWER_STOP_RELEASE = "lower_stop_release"
    UPPER_STOP_RELEASE = "upper_stop_release"


ShiftReleaseIndicator = Callable[[float, NDArray[np.float64]], float]


def build_deadzone_free_boundary_events(
    *,
    limits: CVTShiftOperatingLimits,
) -> tuple[HybridEvent, HybridEvent]:
    """Return the only two boundaries reachable from free deadzone travel.

    A closing primary reaches ``engagement_shift``.  An opening primary reaches
    the lower mechanical stop.  There are deliberately no contact-capacity or
    contact-slip events in deadzone because the primary contact is absent.
    """

    return (
        HybridEvent(
            name=CVTRegimeEvent.ENGAGEMENT_REACHED.value,
            function=lambda _time, vector: float(vector[3] - limits.engagement_shift),
            direction=+1.0,
        ),
        HybridEvent(
            name=CVTRegimeEvent.LOWER_STOP_REACHED.value,
            function=lambda _time, vector: float(vector[3] - limits.lower_stop_shift),
            direction=-1.0,
        ),
    )


def build_engaged_free_boundary_events(
    *,
    limits: CVTShiftOperatingLimits,
) -> tuple[HybridEvent, HybridEvent]:
    """Return the only two geometric boundaries reachable from free engagement."""

    return (
        HybridEvent(
            name=CVTRegimeEvent.DISENGAGEMENT_REACHED.value,
            function=lambda _time, vector: float(vector[3] - limits.engagement_shift),
            direction=-1.0,
        ),
        HybridEvent(
            name=CVTRegimeEvent.UPPER_STOP_REACHED.value,
            function=lambda _time, vector: float(limits.upper_stop_shift - vector[3]),
            direction=-1.0,
        ),
    )


def build_lower_stop_release_event(
    *,
    free_shift_acceleration: ShiftReleaseIndicator,
) -> HybridEvent:
    """Release a lower stop when its unconstrained tendency points inward.

    With positive ``s`` defined as primary closing/upshift, the lower stop
    releases when the free acceleration changes from non-positive to positive.
    ``free_shift_acceleration`` will be supplied by the later deadzone RHS.
    """

    return HybridEvent(
        name=CVTRegimeEvent.LOWER_STOP_RELEASE.value,
        function=free_shift_acceleration,
        direction=+1.0,
    )


def build_upper_stop_release_event(
    *,
    free_shift_acceleration: ShiftReleaseIndicator,
) -> HybridEvent:
    """Release an upper stop when its unconstrained tendency points inward.

    The upper stop releases when free acceleration becomes negative, so the
    event is ``-s_ddot_free`` crossing upward through zero.  The callback is
    supplied later by the constrained engaged-contact RHS.
    """

    return HybridEvent(
        name=CVTRegimeEvent.UPPER_STOP_RELEASE.value,
        function=lambda time, vector: -float(free_shift_acceleration(time, vector)),
        direction=+1.0,
    )
