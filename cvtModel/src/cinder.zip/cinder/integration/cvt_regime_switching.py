"""Event-guided CVT operating-regime transitions and state projections.

This module establishes the complete transition graph before the dedicated
neutral and stop-constrained RHS implementations are added.  It contains no
inline state clamp: any inelastic impact/capture is returned explicitly through
the generic ``HybridTransition.successor_state`` field.
"""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray

from cinder.contact import ContactRegime

from .cvt_contact_events import CVTContactEvent
from .cvt_contact_switching import CVTContactSwitchSettings, resolve_cvt_contact_transition
from .cvt_operating_limits import CVTShiftOperatingLimits
from .cvt_regime import CVTEngagementState, CVTOperatingRegime, CVTShiftConstraint
from .cvt_regime_events import CVTRegimeEvent
from .hybrid import HybridTransition
from .state import CVTDynamicState

if TYPE_CHECKING:
    from .cvt_contact import EngagedCVTContactEvaluator


def classify_initial_cvt_regime(
    *,
    evaluator: "EngagedCVTContactEvaluator",
    state: CVTDynamicState,
    limits: CVTShiftOperatingLimits,
    switching_settings: CVTContactSwitchSettings,
) -> CVTOperatingRegime:
    """Classify an initial state into one physically meaningful regime.

    At the exact engagement position, a nonnegative shift velocity is treated
    as a closing/engaged state; a negative velocity is treated as opening into
    deadzone.  Exact-stop initial states are represented by their matching
    constrained regime, ready for the later constrained RHS implementation.
    """

    _validate_state_within_limits(state=state, limits=limits)
    s = state.shift_position
    if s == limits.lower_stop_shift:
        return CVTOperatingRegime.deadzone_lower_stop()
    if s < limits.engagement_shift or (
        s == limits.engagement_shift and state.shift_speed < 0.0
    ):
        return CVTOperatingRegime.deadzone_free()

    contact = evaluator.classify_initial_regime(
        state=state,
        switching_settings=switching_settings,
    )
    if s == limits.upper_stop_shift:
        return CVTOperatingRegime.engaged_upper_stop(contact_regime=contact)
    return CVTOperatingRegime.engaged_free(contact_regime=contact)


def resolve_cvt_operating_transition(
    *,
    evaluator: "EngagedCVTContactEvaluator",
    time: float,
    vector: NDArray[np.float64],
    old_regime: CVTOperatingRegime,
    fired_event_names: tuple[str, ...],
    limits: CVTShiftOperatingLimits,
    switching_settings: CVTContactSwitchSettings,
) -> HybridTransition[CVTOperatingRegime]:
    """Resolve only successors allowed by the active physical regime.

    Geometry/stop events take precedence over contact events because they
    change which governing equations remain valid.  Contact events are then
    delegated to the established engaged-contact resolver and wrapped back
    into the same free/upper-stop operating constraint.
    """

    state = CVTDynamicState.from_vector(vector)
    _validate_state_within_limits(state=state, limits=limits, tolerance=1.0e-8)
    fired = set(fired_event_names)
    geometry_events = _geometry_events_from(fired)
    contact_events = tuple(name for name in fired_event_names if name not in _REGIME_EVENT_NAMES)

    if old_regime.engagement is CVTEngagementState.DEADZONE:
        return _resolve_deadzone_transition(
            state=state,
            vector=vector,
            old_regime=old_regime,
            geometry_events=geometry_events,
            contact_events=contact_events,
            limits=limits,
            evaluator=evaluator,
            switching_settings=switching_settings,
        )

    return _resolve_engaged_transition(
        time=time,
        state=state,
        vector=vector,
        old_regime=old_regime,
        geometry_events=geometry_events,
        contact_events=contact_events,
        limits=limits,
        evaluator=evaluator,
        switching_settings=switching_settings,
    )


def project_inelastic_shift_stop(
    *,
    vector: NDArray[np.float64],
    shift_position: float,
) -> NDArray[np.float64]:
    """Project a stop arrival to its perfectly inelastic axial post-impact state."""

    projected = np.array(vector, dtype=float, copy=True)
    projected[3] = float(shift_position)
    projected[4] = 0.0
    return projected


def capture_belt_to_secondary_at_disengagement(
    *,
    evaluator: "EngagedCVTContactEvaluator",
    state: CVTDynamicState,
    limits: CVTShiftOperatingLimits,
) -> NDArray[np.float64]:
    """Apply the temporary perfectly inelastic belt-secondary capture map.

    Deadzone assumes the belt remains locked to the secondary.  If a slipping
    secondary reaches primary disengagement, this map conserves angular
    momentum about the secondary shaft for a lumped belt mass at the secondary
    effective radius, then imposes ``v_b = r_s omega_s``.  The approximation is
    explicit here so the later neutral RHS can replace it without touching the
    transition graph.
    """

    boundary_state = replace(state, shift_position=limits.engagement_shift)
    snapshot = evaluator.model.snapshot(state=boundary_state)
    radius = snapshot.geometry.secondary.effective
    belt_mass = snapshot.belt_transport_mass
    secondary_inertia = snapshot.secondary_absolute_rotational_inertia
    combined_inertia = secondary_inertia + belt_mass * radius * radius
    if combined_inertia <= 0.0:
        raise RuntimeError("Deadzone belt-secondary capture has non-positive inertia.")

    captured_secondary_speed = (
        secondary_inertia * state.secondary_angular_speed
        + belt_mass * radius * state.belt_speed
    ) / combined_inertia

    projected = boundary_state.as_vector().copy()
    projected[1] = captured_secondary_speed
    projected[2] = radius * captured_secondary_speed
    return projected


def _resolve_deadzone_transition(
    *,
    state: CVTDynamicState,
    vector: NDArray[np.float64],
    old_regime: CVTOperatingRegime,
    geometry_events: set[CVTRegimeEvent],
    contact_events: tuple[str, ...],
    limits: CVTShiftOperatingLimits,
    evaluator: "EngagedCVTContactEvaluator",
    switching_settings: CVTContactSwitchSettings,
) -> HybridTransition[CVTOperatingRegime]:
    if contact_events:
        raise RuntimeError("Deadzone cannot receive engaged-contact event names.")

    if old_regime.shift_constraint is CVTShiftConstraint.FREE:
        if CVTRegimeEvent.LOWER_STOP_REACHED in geometry_events:
            return HybridTransition(
                next_mode=CVTOperatingRegime.deadzone_lower_stop(),
                reason="deadzone_lower_stop_reached_perfectly_inelastic_impact",
                successor_state=project_inelastic_shift_stop(
                    vector=vector,
                    shift_position=limits.lower_stop_shift,
                ),
            )
        if CVTRegimeEvent.ENGAGEMENT_REACHED in geometry_events:
            boundary_state = CVTDynamicState.from_vector(
                project_inelastic_shift_stop(
                    vector=vector,
                    shift_position=limits.engagement_shift,
                )
            )
            # Engagement is reached while closing.  The axial velocity is not
            # an impact target, so restore the event velocity after using the
            # common boundary-position projection above.
            engaged_vector = boundary_state.as_vector().copy()
            engaged_vector[4] = vector[4]
            engaged_state = CVTDynamicState.from_vector(engaged_vector)
            contact = evaluator.classify_initial_regime(
                state=engaged_state,
                switching_settings=switching_settings,
            )
            return HybridTransition(
                next_mode=CVTOperatingRegime.engaged_free(contact_regime=contact),
                reason="primary_closed_into_engaged_contact",
                successor_state=engaged_state.as_vector(),
            )
        raise RuntimeError("Deadzone free transition received no reachable geometry event.")

    if CVTRegimeEvent.LOWER_STOP_RELEASE in geometry_events:
        return HybridTransition(
            next_mode=CVTOperatingRegime.deadzone_free(),
            reason="lower_stop_released_by_inward_free_shift_tendency",
            successor_state=project_inelastic_shift_stop(
                vector=vector,
                shift_position=limits.lower_stop_shift,
            ),
        )
    raise RuntimeError("Deadzone lower-stop transition requires LOWER_STOP_RELEASE.")


def _resolve_engaged_transition(
    *,
    time: float,
    state: CVTDynamicState,
    vector: NDArray[np.float64],
    old_regime: CVTOperatingRegime,
    geometry_events: set[CVTRegimeEvent],
    contact_events: tuple[str, ...],
    limits: CVTShiftOperatingLimits,
    evaluator: "EngagedCVTContactEvaluator",
    switching_settings: CVTContactSwitchSettings,
) -> HybridTransition[CVTOperatingRegime]:
    assert old_regime.contact_regime is not None

    if old_regime.shift_constraint is CVTShiftConstraint.FREE:
        if CVTRegimeEvent.DISENGAGEMENT_REACHED in geometry_events:
            return HybridTransition(
                next_mode=CVTOperatingRegime.deadzone_free(),
                reason="primary_opened_through_disengagement_boundary",
                successor_state=capture_belt_to_secondary_at_disengagement(
                    evaluator=evaluator,
                    state=state,
                    limits=limits,
                ),
                metadata={
                    "secondary_capture": "perfectly_inelastic_lumped_belt_secondary_capture",
                },
            )
        if CVTRegimeEvent.UPPER_STOP_REACHED in geometry_events:
            return HybridTransition(
                next_mode=CVTOperatingRegime.engaged_upper_stop(
                    contact_regime=old_regime.contact_regime,
                ),
                reason="upper_stop_reached_perfectly_inelastic_impact",
                successor_state=project_inelastic_shift_stop(
                    vector=vector,
                    shift_position=limits.upper_stop_shift,
                ),
                metadata={"deferred_contact_events": contact_events},
            )

    if old_regime.shift_constraint is CVTShiftConstraint.UPPER_STOP:
        if CVTRegimeEvent.UPPER_STOP_RELEASE in geometry_events:
            return HybridTransition(
                next_mode=CVTOperatingRegime.engaged_free(
                    contact_regime=old_regime.contact_regime,
                ),
                reason="upper_stop_released_by_inward_free_shift_tendency",
                successor_state=project_inelastic_shift_stop(
                    vector=vector,
                    shift_position=limits.upper_stop_shift,
                ),
            )

    if not contact_events:
        raise RuntimeError("Engaged transition received no contact or relevant geometry event.")

    contact_transition = resolve_cvt_contact_transition(
        evaluator=evaluator,
        time=time,
        vector=vector,
        old_regime=old_regime.contact_regime,
        fired_event_names=contact_events,
        switching_settings=switching_settings,
    )
    if contact_transition.terminates:
        return HybridTransition(
            next_mode=None,
            reason=contact_transition.reason,
            metadata=contact_transition.metadata,
        )
    assert contact_transition.next_mode is not None
    if old_regime.shift_constraint is CVTShiftConstraint.FREE:
        next_regime = CVTOperatingRegime.engaged_free(
            contact_regime=contact_transition.next_mode,
        )
    else:
        next_regime = CVTOperatingRegime.engaged_upper_stop(
            contact_regime=contact_transition.next_mode,
        )
    return HybridTransition(
        next_mode=next_regime,
        reason=contact_transition.reason,
        metadata=contact_transition.metadata,
    )


def _geometry_events_from(names: set[str]) -> set[CVTRegimeEvent]:
    events: set[CVTRegimeEvent] = set()
    for event in CVTRegimeEvent:
        if event.value in names:
            events.add(event)
    return events


_REGIME_EVENT_NAMES = frozenset(event.value for event in CVTRegimeEvent)


def _validate_state_within_limits(
    *,
    state: CVTDynamicState,
    limits: CVTShiftOperatingLimits,
    tolerance: float = 0.0,
) -> None:
    lower = limits.lower_stop_shift - tolerance
    upper = limits.upper_stop_shift + tolerance
    if not lower <= state.shift_position <= upper:
        raise ValueError(
            "Shift position lies outside CVT operating limits: "
            f"{state.shift_position:.9g} not in [{limits.lower_stop_shift:.9g}, "
            f"{limits.upper_stop_shift:.9g}]."
        )
