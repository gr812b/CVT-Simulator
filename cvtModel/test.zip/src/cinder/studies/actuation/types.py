"""Minimal static clamping-response study types.

The study accepts one complete :class:`CVTAssemblySpec` at a time and samples
one existing pulley actuator.  It deliberately reuses the same
``PulleyActuationContext`` and affine closure relation used by the runtime;
there is no second implementation of an actuator force law here.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from math import isfinite
from types import MappingProxyType
from typing import Mapping, Sequence, TypeAlias

import numpy as np
from numpy.typing import NDArray

from cinder.model.cvt.closure import ClosureUnknown, ClosureUnknowns
from cinder.model.system import CVTAssemblySpec


class PulleyLocation(str, Enum):
    """Select one physical pulley from a complete CVT assembly."""

    PRIMARY = "primary"
    SECONDARY = "secondary"


class ActuationStateCoordinate(str, Enum):
    """State-frozen quantities available to every pulley actuator study."""

    SHIFT_POSITION = "shift_position"
    SHAFT_SPEED = "shaft_speed"
    SHIFT_SPEED = "shift_speed"


ActuationResponseCoordinate: TypeAlias = ActuationStateCoordinate | ClosureUnknown


@dataclass(frozen=True, slots=True)
class ActuationOperatingPoint:
    """One state-frozen point used as the baseline for a clamping study.

    ``time`` is the physical evaluation time supplied to the actuator.
    ``shaft_speed`` belongs to the selected pulley. ``closure_unknowns`` are
    the instantaneous values used to resolve any affine force terms. They are
    normally zero for a simple static force map, except when, for example, a
    torque-reactive helix is evaluated against a chosen shaft torque.
    """

    time: float
    shift_position: float
    shaft_speed: float = 0.0
    shift_speed: float = 0.0
    closure_unknowns: ClosureUnknowns = ClosureUnknowns.zeros()

    def __post_init__(self) -> None:
        for name, value in (
            ("time", self.time),
            ("shift_position", self.shift_position),
            ("shaft_speed", self.shaft_speed),
            ("shift_speed", self.shift_speed),
        ):
            if not isfinite(value):
                raise ValueError(f"{name} must be finite.")
        if not isinstance(self.closure_unknowns, ClosureUnknowns):
            raise TypeError("closure_unknowns must be a ClosureUnknowns instance.")


@dataclass(frozen=True, slots=True)
class ActuationResponseAxis:
    """One real state coordinate or affine closure unknown to sweep."""

    coordinate: ActuationResponseCoordinate
    values: Sequence[float]

    def __post_init__(self) -> None:
        if not isinstance(self.coordinate, (ActuationStateCoordinate, ClosureUnknown)):
            raise TypeError(
                "coordinate must be an ActuationStateCoordinate or ClosureUnknown."
            )
        values = tuple(float(value) for value in self.values)
        if not values:
            raise ValueError(
                "ActuationResponseAxis.values must contain at least one value."
            )
        if not all(isfinite(value) for value in values):
            raise ValueError("ActuationResponseAxis.values must all be finite.")
        object.__setattr__(self, "values", values)

    @property
    def column_key(self) -> str:
        return coordinate_column_key(self.coordinate)


@dataclass(frozen=True, slots=True)
class PulleyClampingForceStudyRequest:
    """Request one static clamping-force field for one pulley in one CVT."""

    cvt: CVTAssemblySpec
    pulley: PulleyLocation
    point: ActuationOperatingPoint
    axes: tuple[ActuationResponseAxis, ...]

    def __post_init__(self) -> None:
        if not isinstance(self.cvt, CVTAssemblySpec):
            raise TypeError("cvt must be a CVTAssemblySpec.")
        if not isinstance(self.pulley, PulleyLocation):
            raise TypeError("pulley must be a PulleyLocation.")
        if not isinstance(self.point, ActuationOperatingPoint):
            raise TypeError("point must be an ActuationOperatingPoint.")
        if not 1 <= len(self.axes) <= 2:
            raise ValueError(
                "axes must contain one or two ActuationResponseAxis values."
            )
        if not all(isinstance(axis, ActuationResponseAxis) for axis in self.axes):
            raise TypeError("axes must contain ActuationResponseAxis values.")
        coordinates = tuple(axis.coordinate for axis in self.axes)
        if len(set(coordinates)) != len(coordinates):
            raise ValueError(
                "Each actuation response axis must use a distinct coordinate."
            )


@dataclass(frozen=True, slots=True)
class ClampingForceResponseField:
    """Self-describing numeric columns from one sampled pulley actuator."""

    pulley: PulleyLocation
    axes: tuple[ActuationResponseAxis, ...]
    columns: Mapping[str, NDArray[np.float64]]

    def __post_init__(self) -> None:
        expected_shape = tuple(len(axis.values) for axis in self.axes)
        if not self.columns:
            raise ValueError("columns must not be empty.")
        normalized: dict[str, NDArray[np.float64]] = {}
        for key, values in self.columns.items():
            if not key or not key.strip():
                raise ValueError("column keys must be non-empty.")
            array = np.asarray(values, dtype=float)
            if array.shape != expected_shape:
                raise ValueError(
                    f"column {key!r} has shape {array.shape}; expected {expected_shape}."
                )
            array = np.array(array, dtype=float, copy=True)
            array.setflags(write=False)
            normalized[key] = array
        object.__setattr__(self, "columns", MappingProxyType(normalized))

    @property
    def shape(self) -> tuple[int, ...]:
        return tuple(len(axis.values) for axis in self.axes)

    @property
    def column_keys(self) -> tuple[str, ...]:
        return tuple(self.columns.keys())

    def column(self, key: str) -> NDArray[np.float64]:
        """Return one named numeric column."""

        try:
            return self.columns[key]
        except KeyError as error:
            raise KeyError(f"No clamping-response column named {key!r}.") from error


def coordinate_column_key(coordinate: ActuationResponseCoordinate) -> str:
    """Return one frontend-friendly, unit-bearing column key."""

    if coordinate is ActuationStateCoordinate.SHIFT_POSITION:
        return "shift_position_m"
    if coordinate is ActuationStateCoordinate.SHAFT_SPEED:
        return "shaft_speed_rad_per_s"
    if coordinate is ActuationStateCoordinate.SHIFT_SPEED:
        return "shift_speed_m_per_s"

    if coordinate is ClosureUnknown.PRIMARY_ANGULAR_ACCELERATION:
        return "primary_angular_acceleration_rad_per_s2"
    if coordinate is ClosureUnknown.SECONDARY_ANGULAR_ACCELERATION:
        return "secondary_angular_acceleration_rad_per_s2"
    if coordinate is ClosureUnknown.BELT_ACCELERATION:
        return "belt_acceleration_m_per_s2"
    if coordinate is ClosureUnknown.SHIFT_ACCELERATION:
        return "shift_acceleration_m_per_s2"
    if coordinate is ClosureUnknown.PRIMARY_TORQUE:
        return "primary_torque_Nm"
    if coordinate is ClosureUnknown.SECONDARY_TORQUE:
        return "secondary_torque_Nm"
    if coordinate is ClosureUnknown.PRIMARY_NORMAL_RESULTANT:
        return "primary_normal_resultant_N"
    if coordinate is ClosureUnknown.SECONDARY_NORMAL_RESULTANT:
        return "secondary_normal_resultant_N"
    raise TypeError(f"Unsupported actuation response coordinate: {coordinate!r}")


def affine_gain_column_key(unknown: ClosureUnknown) -> str:
    """Return a compact, unit-bearing total-force gain column name."""

    if unknown is ClosureUnknown.PRIMARY_ANGULAR_ACCELERATION:
        return "total_gain_primary_angular_acceleration_N_per_rad_per_s2"
    if unknown is ClosureUnknown.SECONDARY_ANGULAR_ACCELERATION:
        return "total_gain_secondary_angular_acceleration_N_per_rad_per_s2"
    if unknown is ClosureUnknown.BELT_ACCELERATION:
        return "total_gain_belt_acceleration_N_per_m_per_s2"
    if unknown is ClosureUnknown.SHIFT_ACCELERATION:
        return "total_gain_shift_acceleration_N_per_m_per_s2"
    if unknown is ClosureUnknown.PRIMARY_TORQUE:
        return "total_gain_primary_torque_N_per_Nm"
    if unknown is ClosureUnknown.SECONDARY_TORQUE:
        return "total_gain_secondary_torque_N_per_Nm"
    if unknown is ClosureUnknown.PRIMARY_NORMAL_RESULTANT:
        return "total_gain_primary_normal_resultant_dimensionless"
    if unknown is ClosureUnknown.SECONDARY_NORMAL_RESULTANT:
        return "total_gain_secondary_normal_resultant_dimensionless"
    raise TypeError(f"Unsupported closure unknown: {unknown!r}")
