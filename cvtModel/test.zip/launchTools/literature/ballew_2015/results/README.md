# Generated comparison results

`run_comparison.py` writes the baseline CINDER-versus-Ballew outputs here by
default, under `results/baseline/`.

Generated files include:

- `comparison_overview.png` - primary RPM, secondary RPM, ratio, and prescribed primary force;
- `cinder_diagnostics.png` - shift, vehicle/load response, and hybrid regime history;
- `cinder_trace.csv` - uniform diagnostic trace;
- `input_rpm_comparison.csv` - CINDER sampled at the native Figure 41 primary-RPM times;
- `output_rpm_comparison.csv` - CINDER sampled at the native Figure 41 secondary-RPM times;
- `ratio_comparison.csv` - derived Ballew/CINDER speed-ratio comparison on the union of the native visible Figure 41 time coordinates;
- `transitions.csv` - hybrid transition/event log;
- `metrics.json` - numerical error metrics and run settings;
- `summary.md` - compact human-readable run summary.

Reference error metrics are evaluated at the digitized Figure 41 time
coordinates, not on the uniform diagnostic trace. The paper data are never
smoothed or tuned to CINDER.
